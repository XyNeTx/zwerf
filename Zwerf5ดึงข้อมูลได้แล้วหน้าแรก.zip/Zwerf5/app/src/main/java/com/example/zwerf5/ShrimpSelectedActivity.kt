package com.example.zwerf5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ShrimpSelectedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shrimp_selected)
    }
}